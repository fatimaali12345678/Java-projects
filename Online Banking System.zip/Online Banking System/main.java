// Online Banking System
class User {
    private String name;
    private String email;
    private String password;

    User(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
    }

    public String getname() { return name; }
    public String getemail() { return email; }
    public String getpassword() { return password; }
    public void setname(String name) { this.name = name; }
    public void setemail(String email) { this.email = email; }
    public void setpassword(String password) { this.password = password; }
}

class Customer extends User {
    Account account;

    Customer(String name, String email, String password) {
        super(name, email, password);
    }
}

class BankEmployees extends User {
    BankEmployees(String name, String email, String password) {
        super(name, email, password);
    }
}

abstract class Account {
    String accountnumber;
    double balance;

    Account(String accountnumber, double balance) {
        this.accountnumber = accountnumber;
        this.balance = balance;
    }

    abstract double calculateInterest();

    void deposit(double amount) {
        balance += amount;
        System.out.println("Balance: " + balance);
    }

    void Withdraw(double amount) {
        if (amount < balance) {
            balance -= amount;
        } else {
            System.out.println("Insufficient amount");
        }
        System.out.println("Balance: " + balance);
    }
}

class CheckingAccount extends Account {
    CheckingAccount(String accountnumber, double balance) {
        super(accountnumber, balance);
    }

    double calculateInterest() {
        return balance * 0.01;
    }
}

class SavingsAccount extends Account {
    SavingsAccount(String accountnumber, double balance) {
        super(accountnumber, balance);
    }

    double calculateInterest() {
        return balance * 0.03;
    }
}

class Transaction {
    String type;
    double amount;
    String date;
    Account sourceAccount;
    Account destinatiomAccount;

    Transaction(String type, double amount, String date, Account sourceAccount, Account destinatiomAccount) {
        this.type = type;
        this.amount = amount;
        this.date = date;
        this.sourceAccount = sourceAccount;
        this.destinatiomAccount = destinatiomAccount;
    }

    void printTransaction() {
        System.out.println("Transaction type: " + type + " | Amount: " + amount + " | Date: " + date);
    }
}

interface LoanService {
    void applyloan(Customer customer, double amount);
    void approvedloan(Customer customer, double amount);
}

interface TransactionService {
    void Withdraw(Account account, double amount);
    void deposit(Account account, double amount);
    void Transfer(Account to, Account from, double amount);
}

class BankManager implements LoanService, TransactionService {
    public void applyloan(Customer customer, double amount) {
        System.out.println("Loan of " + amount + " applied for customer " + customer.getname());
    }

    public void approvedloan(Customer customer, double amount) {
        System.out.println("Loan of " + amount + " approved for customer " + customer.getname());
    }

    public void Withdraw(Account account, double amount) {
        account.Withdraw(amount);
    }

    public void deposit(Account account, double amount) {
        account.deposit(amount);
    }

    public void Transfer(Account to, Account from, double amount) {
        if (from.balance >= amount) {
            from.Withdraw(amount);
            to.deposit(amount);
            System.out.println("Transferred amount: " + amount + " from " + from.accountnumber + " to " + to.accountnumber);
        } else {
            System.out.println("Transfer failed. Insufficient amount.");
        }
    }
}

public class main {
    public static void main(String[] args) {
        // Create customers
        Customer cust1 = new Customer("Fatima", "fatima@gmail.com", "pass123");
        Customer cust2 = new Customer("Ali", "ali@gmail.com", "pass456");

        // Create accounts
        cust1.account = new SavingsAccount("SA123", 5000);
        cust2.account = new CheckingAccount("CA456", 2000);

        // Create bank manager
        BankManager manager = new BankManager();

        // Deposit money
        manager.deposit(cust1.account, 1000);

        // Withdraw money
        manager.Withdraw(cust2.account, 500);

        // Transfer money
        manager.Transfer(cust2.account, cust1.account, 2000);

        // Calculate and print interest
        System.out.println("Interest on " + cust1.getname() + "'s account: " + cust1.account.calculateInterest());
        System.out.println("Interest on " + cust2.getname() + "'s account: " + cust2.account.calculateInterest());

        // Apply for loan
        manager.applyloan(cust1, 10000);
        manager.approvedloan(cust1, 10000);

        // Record a transaction
        Transaction tx = new Transaction("Transfer", 2000, "2025-07-23", cust1.account, cust2.account);
        tx.printTransaction();
    }
}
