import library.*;
import members.*;
import staff.*;

public class function {
    public static void main(String[] args) {
        Library lib = new Library();
        Librarian librarian = new Librarian();

        librarian.addBook(lib, 1, "Java Basics", "John Doe");
        librarian.addBook(lib, 2, "Data Structures", "Jane Smith");

        lib.displayBooks();

        StudentMember student = new StudentMember("Ali", 101);
        FacultyMember faculty = new FacultyMember("Dr. Khan", 201);

        Book book1 = lib.findBook(1);
        student.borrowBook(book1);

        Book book2 = lib.findBook("Data Structures");
        faculty.borrowBook(book2);

        student.borrowBook(book1); 

        student.returnBook(book1);

        double fine = Librarian.calculateFine(3);
        System.out.println("Fine for 3 late days: " + fine);
    }
}