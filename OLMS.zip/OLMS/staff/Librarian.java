package staff;

import library.Book;
import library.Library;

public class Librarian {
    public void addBook(Library lib, int id, String title, String author) {
        lib.addBook(new Book(id, title, author));
        System.out.println("Book added: " + title);
    }

    public static double calculateFine(int lateDays) {
        final double LATE_FEE_PER_DAY = 2.0;
        return lateDays * LATE_FEE_PER_DAY;
    }
}
