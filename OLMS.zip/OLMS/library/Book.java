package library;

public class Book {
    public String title;
    public String author;
    public int bookID;
    public boolean isAvailable;

    public Book(int bookID, String title, String author) {
        this.bookID = bookID;
        this.title = title;
        this.author = author;
        this.isAvailable = true;
    }
}
