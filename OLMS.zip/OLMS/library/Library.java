package library;

public class Library {
    private Book[] books;
    private int count;
    private final int MAX_BOOKS = 100;

    public Library() {
        books = new Book[MAX_BOOKS];
        count = 0;
    }

    public void addBook(Book book) {
        if (count < MAX_BOOKS) {
            books[count++] = book;
        }
    }

    public Book findBook(int id) {
        for (int i = 0; i < count; i++) {
            if (books[i].bookID == id && books[i].isAvailable) {
                return books[i];
            }
        }
        return null;
    }

    public Book findBook(String title) {
        for (int i = 0; i < count; i++) {
            if (books[i].title.equalsIgnoreCase(title) && books[i].isAvailable) {
                return books[i];
            }
        }
        return null;
    }

    public void displayBooks() {
        for (int i = 0; i < count; i++) {
            System.out.println("ID: " + books[i].bookID + ", Title: " + books[i].title + ", Available: " + books[i].isAvailable);
        }
    }
}
