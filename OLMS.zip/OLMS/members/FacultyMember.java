package members;

public class FacultyMember extends Member {
    public FacultyMember(String name, int memberID) {
        super(name, memberID);
    }
}