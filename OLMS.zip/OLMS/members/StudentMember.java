package members;

public class StudentMember extends Member{
    public StudentMember(String name, int memberID) {
        super(name, memberID);
    }
}
