package members;
import library.Book;
public class Member {
    protected String name;
    protected int memberID;
    protected Book[] borrowedBooks;
    protected int borrowedCount;
    protected final int MAX_BOOKS = 5;

    public Member(String name, int memberID) {
        this.name = name;
        this.memberID = memberID;
        this.borrowedBooks = new Book[MAX_BOOKS];
        this.borrowedCount = 0;
    }

    public void borrowBook(Book book) {
        if (borrowedCount < MAX_BOOKS && book.isAvailable) {
            borrowedBooks[borrowedCount++] = book;
            book.isAvailable = false;
            System.out.println(name + " borrowed: " + book.title);
        } else {
            System.out.println("Cannot borrow book: " + book.title);
        }
    }

    public void returnBook(Book book) {
        for (int i = 0; i < borrowedCount; i++) {
            if (borrowedBooks[i] == book) {
                book.isAvailable = true;
                borrowedBooks[i] = borrowedBooks[borrowedCount - 1];
                borrowedBooks[--borrowedCount] = null;
                System.out.println(name + " returned: " + book.title);
                return;
            }
        }
        System.out.println("Book not found in borrowed list.");
    }
}
