import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

class User {
    String id, name, password;
    public User(String id, String name, String password) {
        this.id = id;
        this.name = name;
        this.password = password;
    }
}

class Question {
    String text, type, correctAnswer, topic;
    List<String> options = new ArrayList<>();
    public Question(String text, String type, String correctAnswer, String topic, List<String> options) {
        this.text = text;
        this.type = type;
        this.correctAnswer = correctAnswer;
        this.topic = topic;
        if (options != null) this.options = options;
    }
}

class Quiz {
    int id;
    String courseCode;
    List<Question> questions;
    LocalDateTime startTime, endTime;
    int duration;
    Map<String, String[]> studentAnswers = new HashMap<>(); // Student ID -> answers[]
    public Quiz(int id, String courseCode, List<Question> questions, LocalDateTime startTime, LocalDateTime endTime, int duration) {
        this.id = id;
        this.courseCode = courseCode;
        this.questions = questions;
        this.startTime = startTime;
        this.endTime = endTime;
        this.duration = duration;
    }
}

public class ExaminationSystem {
    static Scanner sc = new Scanner(System.in);
    static User teacher = new User("t1", "Ali", "123");
    static List<User> students = new ArrayList<>();
    static List<Question> questionBank = new ArrayList<>();
    static List<Quiz> quizzes = new ArrayList<>();
    static Set<String> attemptedQuizzes = new HashSet<>();

    public static void main(String[] args) {
        students.add(new User("s1", "Fatima", "789"));
        students.add(new User("s2", "Ahmed", "abc"));
        students.add(new User("s3", "Zainab", "xyz"));
        students.add(new User("s4", "Usman", "456"));
        students.add(new User("s5", "Ayesha", "753"));

        while (true) {
            System.out.println("Welcome to Examination System");
            System.out.print("Enter ID: "); String id = sc.nextLine();
            System.out.print("Enter Password: "); String pw = sc.nextLine();

            if (id.equals(teacher.id) && pw.equals(teacher.password)) {
                System.out.println("Welcome, " + teacher.name);
                handleTeacher();
            } else {
                Optional<User> studentOpt = students.stream().filter(s -> s.id.equals(id) && s.password.equals(pw)).findFirst();
                if (studentOpt.isPresent()) {
                    User stu = studentOpt.get();
                    System.out.println("Welcome, " + stu.name);
                    handleStudent(stu);
                } else {
                    System.out.println("Invalid credentials.\n");
                }
            }
        }
    }

    static void handleTeacher() {
        while (true) {
            System.out.println("1. Create Question Bank\n2. Create Quiz\n3. View Results & Attendance\n4. Logout");
            String ch = sc.nextLine();
            if (ch.equals("1")) {
                System.out.print("Enter question text: ");
                String text = sc.nextLine();
                System.out.print("Enter type (MCQ/TF): ");
                String type = sc.nextLine();
                List<String> options = new ArrayList<>();
                if (type.equalsIgnoreCase("MCQ")) {
                    for (int i = 1; i <= 4; i++) {
                        while (true) {
                            System.out.print("Option " + i + ": ");
                            String opt = sc.nextLine();
                            if (opt.isEmpty()) {
                                System.out.println("Please enter option.");
                            } else {
                                options.add(opt);
                                break;
                            }
                        }
                    }
                }
                String correct;
                while (true) {
                    System.out.print("Correct Answer: ");
                    correct = sc.nextLine();
                    if (correct.isEmpty()) {
                        System.out.println("Please enter correct answer.");
                    } else break;
                }
                System.out.print("Topic: "); String topic = sc.nextLine();
                questionBank.add(new Question(text, type, correct, topic, options));
                System.out.println("Question Added.\n");
            } else if (ch.equals("2")) {
                System.out.print("Course Code: "); String cc = sc.nextLine();
                System.out.print("# of Questions: "); int qn = Integer.parseInt(sc.nextLine());
                System.out.print("Enter Start DateTime (yyyy-MM-ddTHH:mm): ");
                LocalDateTime st = LocalDateTime.parse(sc.nextLine());
                System.out.print("Enter End DateTime (yyyy-MM-ddTHH:mm): ");
                LocalDateTime et = LocalDateTime.parse(sc.nextLine());
                System.out.print("Duration for each student (minutes): ");
                int dur = Integer.parseInt(sc.nextLine());

                Collections.shuffle(questionBank);
                List<Question> selected = new ArrayList<>(questionBank.subList(0, qn));
                int id = new Random().nextInt(1000);
                quizzes.add(new Quiz(id, cc, selected, st, et, dur));
                System.out.println("Quiz Created with ID: " + id + "\n");
            } else if (ch.equals("3")) {
                for (Quiz quiz : quizzes) {
                    System.out.println("\nResults for Quiz ID: " + quiz.id);
                    System.out.println("-----------------------------------------------------");
                    System.out.printf("%-10s %-10s %-10s\n", "ID", "Name", "Status");
                    for (User stu : students) {
                        if (quiz.studentAnswers.containsKey(stu.id)) {
                            String[] ans = quiz.studentAnswers.get(stu.id);
                            int score = 0;
                            for (int i = 0; i < quiz.questions.size(); i++) {
                                if (ans[i] != null && ans[i].equalsIgnoreCase(quiz.questions.get(i).correctAnswer)) {
                                    score++;
                                }
                            }
                            System.out.printf("%-10s %-10s %d/%d\n", stu.id, stu.name, score, quiz.questions.size());
                        } else {
                            System.out.printf("%-10s %-10s Absent\n", stu.id, stu.name);
                        }
                    }
                }
            } else return;
        }
    }

    static void handleStudent(User student) {
        while (true) {
            System.out.println("1. Attempt Quiz\n2. Logout");
            String ch = sc.nextLine();
            if (ch.equals("1")) {
                LocalDateTime now = LocalDateTime.now();
                for (Quiz quiz : quizzes) {
                    if (!quiz.studentAnswers.containsKey(student.id) &&
                        now.isAfter(quiz.startTime) && now.isBefore(quiz.endTime)) {

                        System.out.println("Attempting Quiz ID: " + quiz.id);
                        String[] answers = new String[quiz.questions.size()];
                        LocalDateTime deadline = now.plusMinutes(quiz.duration);

                        for (int i = 0; i < quiz.questions.size(); i++) {
                            if (LocalDateTime.now().isAfter(deadline)) {
                                System.out.println("Time up! Moving to submission.");
                                break;
                            }
                            Question q = quiz.questions.get(i);
                            System.out.println("Q: " + q.text);
                            if (q.type.equalsIgnoreCase("MCQ")) {
                                for (int j = 0; j < q.options.size(); j++) {
                                    System.out.println((j + 1) + ". " + q.options.get(j));
                                }
                            }
                            System.out.print("Your answer: ");
                            String ans = sc.nextLine();
                            while (true) {
                                System.out.println("1. Submit\n2. Change Answer");
                                String op = sc.nextLine();
                                if (op.equals("1")) break;
                                else {
                                    System.out.print("Re-enter your answer: ");
                                    ans = sc.nextLine();
                                }
                            }
                            answers[i] = ans;
                        }
                        quiz.studentAnswers.put(student.id, answers);
                        System.out.println("Quiz Submitted.\n");
                        int score = 0;
                        for (int i = 0; i < quiz.questions.size(); i++) {
                            if (answers[i] != null && answers[i].equalsIgnoreCase(quiz.questions.get(i).correctAnswer)) {
                                score++;
                            }
                        }
                        System.out.println("Your Grade: " + score + "/" + quiz.questions.size());
                        return;
                    } else if (quiz.studentAnswers.containsKey(student.id)) {
                        System.out.println("\nYou have already attempted this quiz.\n");
                        return;
                    }
                }
                System.out.println("No active quiz right now.\n");
            } else return;
        }
    }
}
