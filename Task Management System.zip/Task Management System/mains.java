// Task Management System

class User {
    private String name;
    private String email;
    private String password;

    User(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
    }

    public String getname() { return name; }
    public String getemail() { return email; }
    public String getpassword() { return password; }
    public void setname(String name) { this.name = name; }
    public void setemail(String email) { this.email = email; }
    public void setpassword(String password) { this.password = password; }
}

class Teamleads extends User {
    static int registerteamlead = 0;

    Teamleads(String name, String email, String password) {
        super(name, email, password);
        registerteamlead++;
    }

    int registerteamlead() {
        return registerteamlead;
    }

    void assigntask(Task task, Employees employees) {
        System.out.println("Team lead " + getname() + " assigned task \"" + task.title + "\" to employee " + employees.getname());
    }
}

class Employees extends User {
    static int registeredEmployees = 0;

    Employees(String name, String email, String password) {
        super(name, email, password);
        registeredEmployees++;
    }

    int registeredEmployees() {
        return registeredEmployees;
    }

    void markCompleted(Task task) {
        task.setstatus("Completed");
        System.out.println("Employee " + getname() + " completed the task \"" + task.title + "\"");
    }

    void submitwork(Task task, SubmisssionMethod submisssionMethod) {
        submisssionMethod.submit(task.title);
    }
}

class Task {
    int taskid;
    String title;
    String description;
    String deadline;
    private String status;
    Employees employees;
    static int totaltask = 0;
    static int completedtask = 0;

    Task(int taskid, String title, String description, String deadline, String status, Employees employees) {
        this.taskid = taskid;
        this.title = title;
        this.description = description;
        this.deadline = deadline;
        this.status = "Pending";
        this.employees = employees;
        totaltask++;
    }

    public String getstatus() { return status; }

    public void setstatus(String status) {
        this.status = status;
        if (status.equalsIgnoreCase("Completed")) {
            completedtask++;
        }
    }

    static int totaltask() {
        return totaltask;
    }

    static int completedtask() {
        return completedtask;
    }
}

interface SubmisssionMethod {
    void submit(String tasktitle);
}

class PDFsubmission implements SubmisssionMethod {
    public void submit(String tasktitle) {
        System.out.println("Submitting \"" + tasktitle + "\" as PDF");
    }
}

class GoogleDocsubmission implements SubmisssionMethod {
    public void submit(String tasktitle) {
        System.out.println("Submitting \"" + tasktitle + "\" as Google Doc");
    }
}

class GithubLinksubmission implements SubmisssionMethod {
    public void submit(String tasktitle) {
        System.out.println("Submitting \"" + tasktitle + "\" as GitHub Link");
    }
}

public class mains {
    public static void main(String[] args) {
        Teamleads lead = new Teamleads("Ali", "ali@company.com", "pass123");
        Employees emp1 = new Employees("Fatima", "fatima@gmail.com", "emp123");

        Task task1 = new Task(1, "Write Report", "Prepare quarterly report", "2025-07-31", "Pending", emp1);

        lead.assigntask(task1, emp1);

        emp1.markCompleted(task1);

        SubmisssionMethod pdf = new PDFsubmission();
        emp1.submitwork(task1, pdf);

        SubmisssionMethod googleDoc = new GoogleDocsubmission();
        emp1.submitwork(task1, googleDoc);

        SubmisssionMethod github = new GithubLinksubmission();
        emp1.submitwork(task1, github);

        System.out.println("Total tasks created: " + Task.totaltask());
        System.out.println("Total tasks completed: " + Task.completedtask());
        System.out.println("Total team leads registered: " + lead.registerteamlead());
        System.out.println("Total employees registered: " + emp1.registeredEmployees());
    }
}
