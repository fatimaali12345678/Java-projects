// Library Management System

class User {
    private String name;
    private String email;
    private String password;

    User(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
    }

    public String getname() { return name; }
    public String getemail() { return email; }
    public String getpassword() { return password; }
    public void setname(String name) { this.name = name; }
    public void setemail(String email) { this.email = email; }
    public void setpassword(String password) { this.password = password; }
}

class Member extends User {
    Member(String name, String email, String password) {
        super(name, email, password);
    }
}

class Librarian extends User {
    Librarian(String name, String email, String password) {
        super(name, email, password);
    }

    public void addbook(Book book) {
        System.out.println("Book \"" + book.title + "\" added.");
    }

    public void removebook(Book book) {
        System.out.println("Book \"" + book.title + "\" removed.");
    }
}

abstract class Book {
    String title;
    String author;
    String isbn;

    Book(String title, String author, String isbn) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
    }

    abstract double calculateFine(int Latedays);
}

class Textbook extends Book {
    Textbook(String title, String author, String isbn) {
        super(title, author, isbn);
    }

    double calculateFine(int Latedays) {
        return Latedays * 1.0; // $1 per day
    }
}

class Referencebook extends Book {
    Referencebook(String title, String author, String isbn) {
        super(title, author, isbn);
    }

    double calculateFine(int Latedays) {
        return Latedays * 2.0; // $2 per day
    }
}

class BorrowRecord {
    String borrowdate;
    String returndate;
    Book book;
    Member member;

    BorrowRecord(String borrowdate, String returndate, Book book, Member member) {
        this.borrowdate = borrowdate;
        this.returndate = returndate;
        this.book = book;
        this.member = member;
    }

    void printdetails() {
        System.out.println("Borrowed Book: \"" + book.title + "\", Borrow Date: " + borrowdate + ", Return Date: " + returndate);
    }
}

interface BorrowServices {
    void borrowbook(BorrowRecord record);
    void returnbook(BorrowRecord record);
    void renewbook(BorrowRecord record);
}

class LibraryManager implements BorrowServices {
    public void borrowbook(BorrowRecord record) {
        System.out.println("Book borrowed: \"" + record.book.title + "\" by member: " + record.member.getname());
    }

    public void returnbook(BorrowRecord record) {
        System.out.println("Returned book: \"" + record.book.title + "\" by member: " + record.member.getname());
    }

    public void renewbook(BorrowRecord record) {
        System.out.println("Book renewed: \"" + record.book.title + "\" by member: " + record.member.getname());
    }
}

public class practice {
    public static void main(String[] args) {
        Librarian librarian = new Librarian("Ali", "ali@library.com", "lib123");
        Member member = new Member("Fatima", "fatima@gmail.com", "mem123");

        Book book1 = new Textbook("Java Programming", "John Doe", "ISBN1234");
        Book book2 = new Referencebook("Data Structures", "Jane Smith", "ISBN5678");

        librarian.addbook(book1);
        librarian.addbook(book2);

        BorrowRecord record1 = new BorrowRecord("2025-07-20", "2025-07-27", book1, member);

        LibraryManager manager = new LibraryManager();
        manager.borrowbook(record1);

        record1.printdetails();

        manager.returnbook(record1);

        int lateDays = 3;
        double fine = book1.calculateFine(lateDays);
        System.out.println("Late fine for \"" + book1.title + "\" for " + lateDays + " days is: $" + fine);
    }
}
