// E-learning platform
class User {
    private String name;
    private String email;
    private String password;

    User(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
    }

    public String getname() { return name; }
    public String getemail() { return email; }
    public String getpassword() { return password; }
    public void setname(String name) { this.name = name; }
    public void setemail(String email) { this.email = email; }
    public void setpassword(String password) { this.password = password; }
}

class Students extends User {
    Students(String name, String email, String password) {
        super(name, email, password);
    }

    void enrollInCourse(Courses courses) {
        System.out.println(getname() + " enrolled in course: " + courses.getTitle());
    }
}

class Instructor extends User {
    Instructor(String name, String email, String password) {
        super(name, email, password);
    }

    void teachCourse(Courses courses) {
        System.out.println(getname() + " is teaching course: " + courses.getTitle());
    }
}

class Courses {
    private String title;
    private String description;
    private double fee;
    private Instructor instructor;
    private Students students;

    Courses(String title, String description, double fee, Instructor instructor, Students students) {
        this.title = title;
        this.description = description;
        this.fee = fee;
        this.instructor = instructor;
        this.students = students;
    }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getFee() { return fee; }
    public void setFee(double fee) { this.fee = fee; }

    public Instructor getInstructor() { return instructor; }
    public void setInstructor(Instructor instructor) { this.instructor = instructor; }

    public Students getStudents() { return students; }
    public void setStudents(Students students) { this.students = students; }
}

interface CourseServices {
    void createCourse(Courses courses);
    void deleteCourse(Courses courses);
    void enrollCourse(Courses courses);
}

class CourseManager implements CourseServices {
    public void createCourse(Courses courses) {
        System.out.println("Course: " + courses.getTitle() + " created by: " + courses.getInstructor().getname());
    }

    public void deleteCourse(Courses courses) {
        System.out.println("Course deleted: " + courses.getTitle());
    }

    public void enrollCourse(Courses courses) {
        System.out.println("Student enrolled in course: " + courses.getTitle());
    }
}

interface PaymentMethod {
    void processpayment(double amount);
}

class Cardpayment implements PaymentMethod {
    public void processpayment(double amount) {
        System.out.println(amount + " paid by card");
    }
}

class Cashpayment implements PaymentMethod {
    public void processpayment(double amount) {
        System.out.println(amount + " paid by cash");
    }
}

class mains {
    public static void main(String[] args) {
        // Create instructor and student
        Instructor instructor1 = new Instructor("Dr. Ahmed", "ahmed@gmail.com", "pass123");
        Students student1 = new Students("Fatima", "fatima@gmail.com", "pass456");

        // Create course
        Courses course1 = new Courses("Java Programming", "Learn Java from basics to OOP", 5000, instructor1, student1);

        // Course Manager
        CourseManager manager = new CourseManager();
        manager.createCourse(course1);

        // Instructor teaches course
        instructor1.teachCourse(course1);

        // Student enrolls
        student1.enrollInCourse(course1);
        manager.enrollCourse(course1);

        // Payment
        PaymentMethod payment = new Cardpayment();
        payment.processpayment(course1.getFee());
    }
}
