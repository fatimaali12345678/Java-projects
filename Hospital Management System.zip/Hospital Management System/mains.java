// Hospital Management System
class User {
    private String name;
    private String email;
    private String password;

    User(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
    }

    public String getname() { return name; }
    public String getemail() { return email; }
    public String getpassword() { return password; }
    public void setname(String name) { this.name = name; }
    public void setemail(String email) { this.email = email; }
    public void setpassword(String password) { this.password = password; }
}

class Patient extends User {
    Patient(String name, String email, String password) {
        super(name, email, password);
    }
}

abstract class Doctor extends User {
    String specialiazaton;

    Doctor(String name, String email, String password, String specialiazation) {
        super(name, email, password);
        this.specialiazaton = specialiazation;
    }

    abstract void diagnose();
}

class Specialist extends Doctor {
    Specialist(String name, String email, String password, String specialiazation) {
        super(name, email, password, specialiazation);
    }

    void diagnose() {
        System.out.println(getname() + " (Specialist) is diagnosing a specific condition");
    }
}

class GeneralPhysician extends Doctor {
    GeneralPhysician(String name, String email, String password, String specialiazation) {
        super(name, email, password, specialiazation);
    }

    void diagnose() {
        System.out.println(getname() + " (General Physician) is diagnosing a general condition");
    }
}

class Appointment {
    int AppointmentID;
    Patient patient;
    Doctor doctor;
    String date;
    private String Status;

    Appointment(int AppointmentID, Patient patient, Doctor doctor, String date, String Status) {
        this.AppointmentID = AppointmentID;
        this.patient = patient;
        this.doctor = doctor;
        this.date = date;
        this.Status = "Scheduled";
    }

    public String getStatus() { return Status; }
    public void setStatus(String Status) { this.Status = Status; }

    void printDetails() {
        System.out.println("Appointment ID: " + AppointmentID +
                ", Patient: " + patient.getname() +
                ", Doctor: " + doctor.getname() +
                ", Date: " + date +
                ", Status: " + Status);
    }
}

interface AppointmentServices {
    void BookAppointment(Appointment appointment);
    void CompleteAppointment(Appointment appointment);
    void CancelAppointment(Appointment appointment);
}

interface Paymentmethod {
    void processpayment(double amount);
}

class Cashpayment implements Paymentmethod {
    public void processpayment(double amount) {
        System.out.println("Amount: " + amount + " paid by cash");
    }
}

class Insurancepayment implements Paymentmethod {
    public void processpayment(double amount) {
        System.out.println("Amount: " + amount + " paid by insurance");
    }
}

class HospitalManager implements AppointmentServices {
    public void BookAppointment(Appointment appointment) {
        appointment.setStatus("Scheduled");
        System.out.println("Appointment booked successfully");
    }

    public void CancelAppointment(Appointment appointment) {
        appointment.setStatus("Canceled");
        System.out.println("Appointment canceled");
    }

    public void CompleteAppointment(Appointment appointment) {
        appointment.setStatus("Completed");
        System.out.println("Appointment completed");
    }
}

public class mains {
    public static void main (String[] args) {
        // Create patient and doctors
        Patient patient1 = new Patient("Fatima", "fatima@gmail.com", "pass123");
        Specialist specialist = new Specialist("Dr. Ahmed", "ahmed@gmail.com", "doc123", "Cardiology");
        GeneralPhysician gp = new GeneralPhysician("Dr. Ali", "ali@gmail.com", "doc456", "General Medicine");

        // Create appointments
        Appointment appt1 = new Appointment(101, patient1, specialist, "2025-07-24", "Scheduled");
        Appointment appt2 = new Appointment(102, patient1, gp, "2025-07-25", "Scheduled");

        // Hospital manager to manage appointments
        HospitalManager manager = new HospitalManager();
        manager.BookAppointment(appt1);
        manager.BookAppointment(appt2);

        // Doctors diagnose
        specialist.diagnose();
        gp.diagnose();

        // Print appointment details
        appt1.printDetails();
        appt2.printDetails();

        // Complete and cancel appointments
        manager.CompleteAppointment(appt1);
        manager.CancelAppointment(appt2);

        // Payment
        Paymentmethod payment1 = new Cashpayment();
        payment1.processpayment(5000);

        Paymentmethod payment2 = new Insurancepayment();
        payment2.processpayment(7000);
    }
}
